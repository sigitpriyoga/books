<?php
class Book extends CI_Controller {

	public function __construct(){
		parent::__construct();
		
		// cek keberadaan session 'username'	
		if (!isset($_SESSION['username'])){
			// jika session 'username' blm ada, maka arahkan ke kontroller 'login'
			redirect('login');
		}
	}


	// method hapus data buku berdasarkan id
	public function delete($id){
		$this->book_model->delBook($id);
		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('dashboard/books');
	}

	// method untuk tambah data buku
	public function insert(){

		// target direktori fileupload
		$target_dir = "c:/xampp/htdocs/books/assets/images/";
		
		// baca nama file upload
		$filename = $_FILES["imgcover"]["name"];

		// menggabungkan target dir dengan nama file
		$target_file = $target_dir . basename($filename);

		// proses upload
		move_uploaded_file($_FILES["imgcover"]["tmp_name"], $target_file);

		// baca data dari form insert buku
		$judul = $_POST['judul'];
		$pengarang = $_POST['pengarang'];
		$penerbit = $_POST['penerbit'];
		$sinopsis = $_POST['sinopsis'];
		$thnterbit = $_POST['thnterbit'];
		$idkategori = $_POST['idkategori'];

		// panggil method insertBook() di model 'book_model' untuk menjalankan query insert
		$this->book_model->insertBook($judul, $pengarang, $penerbit, $thnterbit, $sinopsis, $idkategori, $filename);

		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('dashboard/books');
	}

	// method untuk edit data buku berdasarkan id
	public function edit($id){
		$data['kategori'] = $this->book_model->getKategori();
		$data['fullname'] = $_SESSION['fullname'];
		$data['role']= $_SESSION['role'];

		// panggil method findBook() dari model book_model untuk menjalankan query cari data
		$data['book'] = $this->book_model->showBook($id);
		
		$this->load->view('dashboard/header', $data);
        $this->load->view('dashboard/edit', $data);
        $this->load->view('dashboard/footer');
	}
	public function deletekat($id){
		$this->book_model->delKategori($id);
		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('dashboard/kategori');
	}
	public function editkat($id){
		$data['kategori'] = $this->book_model->showKategori($id);
		$data['fullname'] = $_SESSION['fullname'];
		$this->load->view('dashboard/header', $data);
        $this->load->view('dashboard/editkat', $data);
        $this->load->view('dashboard/footer');
	}
	public function updatekat(){
		// target direktori fileupload

		$idkategori= $_POST['idkategori'];
		$kategori = $_POST['kategori'];
		
	$this->book_model->updatekat($idkategori, $kategori);
	redirect('dashboard/kategori');
	}
	public function insertkat(){
        $data['fullname'] = $_SESSION['fullname'];

        $kategori = $_POST['kategori'];

        // panggil method insertBook() di model 'book_model' untuk menjalankan query insert
        $this->book_model->insertkat($kategori);

        // arahkan ke method 'books' di kontroller 'dashboard'
        redirect('dashboard/kategori');
    }
	// method untuk update data buku berdasarkan id
	public function update(){
		// target direktori fileupload
		$target_dir = "c:/xampp/htdocs/books/assets/images/";
		
		// baca nama file upload
		$filename = $_FILES["imgcover"]["name"];

		// menggabungkan target dir dengan nama file
		$target_file = $target_dir . basename($filename);

		// proses upload
		move_uploaded_file($_FILES["imgcover"]["tmp_name"], $target_file);
		$idbuku = $_POST['idbuku'];
		$judul = $_POST['judul'];
		$pengarang = $_POST['pengarang'];
		$penerbit = $_POST['penerbit'];
		$sinopsis = $_POST['sinopsis'];
		$thnterbit = $_POST['thnterbit'];
		$idkategori = $_POST['idkategori'];
		
	$this->book_model->updateBook($idbuku, $judul, $pengarang, $penerbit, $thnterbit, $sinopsis, $idkategori, $filename);
	redirect('dashboard/books');
	}

	// method untuk mencari data buku berdasarkan 'key'
	public function findbooks(){
		
		// baca key dari form cari data
		$key = $_POST['key'];
		$data['fullname'] = $_SESSION['fullname'];
		$data['role']= $_SESSION['role'];
		// panggil method findBook() dari model book_model untuk menjalankan query cari data
		$data['book'] = $this->book_model->findBook($key);

		// tampilkan hasil pencarian di view 'dashboard/books'
		$this->load->view('dashboard/header', $data);
        $this->load->view('dashboard/books', $data);
        $this->load->view('dashboard/footer');
	}
	public function view($id){
		
		// baca key dari form cari data
		$data['fullname'] = $_SESSION['fullname'];
		$data['role']= $_SESSION['role'];
		// panggil method findBook() dari model book_model untuk menjalankan query cari data
		$data['book'] = $this->book_model->showBook($id);
		$data['kategori']=$this->book_model->getKategori($id);


		// tampilkan hasil pencarian di view 'dashboard/books'
		$this->load->view('dashboard/header', $data);
        $this->load->view('dashboard/view', $data);
        $this->load->view('dashboard/footer');
	}
	public function viewuser(){
		
		// baca key dari form cari data
		$data['fullname'] = $_SESSION['fullname'];
		$data['role']= $_SESSION['role'];
		// panggil method findBook() dari model book_model untuk menjalankan query cari data
		$data['book'] = $this->book_model->showBook($id);
		$data['kategori']=$this->book_model->getKategori($id);


		// tampilkan hasil pencarian di view 'dashboard/books'
		$this->load->view('dashboard/header', $data);
        $this->load->view('dashboard/view', $data);
        $this->load->view('dashboard/footer');
	}
	public function deleteuser($username){
		$this->book_model->deluser($username);
		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('dashboard/user');
	}
	public function edituser($username){
		$data['user'] = $this->book_model->showuser($username);
		$data['fullname'] = $_SESSION['fullname'];
		$data['role']= $_SESSION['role'];
		$this->load->view('dashboard/header', $data);
        $this->load->view('dashboard/edituser', $data);
        $this->load->view('dashboard/footer');
	}
	public function updateusers(){
		
		$username = $_POST['username'];
		$password = $_POST['password'];
		$fullname = $_POST['fullname'];
		$role = $_POST['role'];
	$this->book_model->updateuser($username, $password, $fullname, $role);
	redirect('dashboard/user');
	}
	public function adduser(){
		$username = $_POST['username'];
		$password = $_POST['password'];
		$fullname = $_POST['fullname'];
		$role = $_POST['role'];
		// panggil method insertBook() di model 'book_model' untuk menjalankan query insert
		$this->book_model->insertuser($username, $password, $fullname, $role);

		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('dashboard/user');
	}
}
?>