<?php

class User_model extends CI_Model {

	// method untuk membaca data profile user
	public function getUserProfile($username){
		// db get_where = mencari ditabel user dimana user name == variabel $username
		$query = $this->db->get_where('users', array('username' => $username));
		return $query->row_array();
	}
}

?>