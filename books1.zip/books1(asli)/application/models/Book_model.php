<?php

class Book_model extends CI_Model {

	// method untuk menampilkan data buku
	public function showBook($id = false){
		// membaca semua data buku dari tabel 'books'
		if ($id == false){
			$query = $this->db->query("SELECT * FROM books, kategori WHERE books.idkategori = kategori.idkategori");
			return $query->result_array();
			//result_array 
		} else {
			// membaca data buku berdasarkan id
			$query = $this->db->get_where('books', array("idbuku" => $id));
			return $query->row_array();
		}
	}

	// method untuk hapus data buku berdasarkan id
	public function delBook($id){
		$this->db->delete('books', array("idbuku" => $id));
	}

	// method untuk mencari data buku berdasarkan key
	public function findBook($key){

		$query = $this->db->query("SELECT * FROM books WHERE judul LIKE '%$key%' 
									OR pengarang LIKE '%$key%' 
									OR penerbit LIKE '%$key%'
									OR sinopsis LIKE '%$key%'
									OR thnterbit LIKE '%$key%'");
		return $query->result_array();
	}

	// method untuk insert data buku ke tabel 'books'
	public function insertBook($judul, $pengarang, $penerbit, $thnterbit, $sinopsis, $idkategori, $filename){
		$data = array(
					"judul" => $judul,
					"pengarang" => $pengarang,
					"penerbit" => $penerbit,
					"sinopsis" => $sinopsis,
					"idkategori" => $idkategori,
					"thnterbit" => $thnterbit,
					"imgfile" => $filename
		);
		$query = $this->db->insert('books', $data);
	}
	public function updateBook($idbuku, $judul, $pengarang, $penerbit, $thnterbit, $sinopsis, $idkategori, $filename){
		$data = array(
					"idbuku"=> $idbuku,
					"judul" => $judul,
					"pengarang" => $pengarang,
					"penerbit" => $penerbit,
					"sinopsis" => $sinopsis,
					"idkategori" => $idkategori,
					"thnterbit" => $thnterbit,
					"imgfile" => $filename
		);
		$this->db->where("idbuku", $idbuku);
		$query = $this->db->update('books',$data);
	}
	// method untuk membaca data kategori buku dari tabel 'kategori'
	public function getKategori($id=false){
		
		if ($id == false){
			$query = $this->db->get('kategori');
		return $query->result_array();
			//result_array 
		} else {
			// membaca data buku berdasarkan id
			$query = $this->db->query("SELECT * FROM books, kategori WHERE books.idkategori = kategori.idkategori");
			return $query->row()->kategori;
		}
	}
	public function showKategori($id){
		$query = $this->db->get_where('kategori', array("idkategori" => $id));
			return $query->row_array();
		}
	public function delKategori($id){
		$this->db->delete('kategori', array("idkategori" => $id));
	}
	public function updatekat($idkategori, $kategori){
		$data = array(
					"idkategori" => $idkategori,
					"kategori"=> $kategori
		);
		$this->db->where("idkategori", $idkategori);
		$query = $this->db->update('kategori',$data);
	}
	public function insertkat($kategori){
		$data = array(
					"kategori" => $kategori,
		);
		$query = $this->db->insert('kategori', $data);
	}
	public function getUser($username=false){
		
		if ($username == false){
			$query = $this->db->get('users');
		return $query->result_array();
			//result_array 
		} else {
			// membaca data buku berdasarkan id
			$query = $this->db->query("SELECT * FROM users WHERE username = $username");
			return $query->row()->users;
		}
	}
	// method untuk menghitung jumlah buku berdasarkan idkategori
	public function countByCat($idkategori){
		$query = $this->db->query("SELECT count(*) as jum FROM books WHERE idkategori = '$idkategori'");
		return $query->row()->jum;
	}
	public function deluser($username){
		$this->db->delete('users', array("username" => $username));
	}
	public function showuser($username){
		$query = $this->db->get_where('users', array("username" => $username));
			return $query->row_array();
		}
	public function tampiluser(){
	$query = $this->db->query("SELECT * FROM users ");
	return $query->result_array();
	}
	public function updateuser($username, $password, $fullname, $role){
		$data = array(
					"username"=> $username,
					"password" => $password,
					"fullname" => $fullname,
					"role"	=> $role
				);
		$this->db->where("username", $username);
		$query = $this->db->update('users',$data);
	}
	public function insertuser($username, $password, $fullname, $role){
		$data = array(
					"username"=> $username,
					"password" => $password,
					"fullname" => $fullname,
					"role"	=> $role,
		);
		$query = $this->db->insert('users', $data);
	}
	public function getRow($limit, $start){
        $query = $this->db->get('books', $limit, $start);
        return $query->result_array();
    }
    public function count($key=false){
		$query = $this->db->query("SELECT COUNT(*) as 'jml' FROM books");
		return $query->row()->jml;
	}
}
?>